# CMPUT 291 - Mini Project 2
# Author: Daniel Zhou
# November 2016
import itertools
from closure import *
#===============================================================================

# NF3 performs the third normal form decomposition. It requires the list of
# functional dependencies from some source. 
#
# If in the event some attribute is not connected to any functional dependency
# then it is not captured by the function. Presumably these can be added to the
# relation containing the super key
#
# Input Format:
# Functional Dependneces should be converted into the following format.
#   
# For example:
# T = [("ABH","CK"),("A","D"),("C","E"),("BGH","F"),("F","AD"),("E","F"),("BH","E")]
# NF3decomp(T)
# 
# The input is a list containing set elements. These elements are in the for
# (X,Y) where X and Y are the functional dependency X -> Y.
# X and Y should be expressed as a sequence of capitalized strings.
#
# Output Format:
# The output format is similar to the input format. It is a list of sets
# containing the functional dependencies of a sub relation of R
#
# For example:
# T = [('AB', 'CDE'),('C', 'AD'),('D', 'AE'),('B', 'F')]
# NF3decomp(T)
# Returns>>> [('D', 'AE'), ('B', 'F'), ('AB', 'C'), ('C', 'D')]
# As such each of the 4 returned set are to be made into a table.



def NF3decomp(FDependencies):
    # Input Transformation
    Dependencies = min_closure(FDependencies)
    # Output Template
    Output = []
    # Split Original Table in FDependency Tables
    Distinct_Attributes = []
    # Make List of distinct X's in X -> Y
    for FD in FDependencies:
        if FD[0] not in Distinct_Attributes:
            Distinct_Attributes.append(FD[0])
    # For each distinct X collect all elements relating to X.
    for i in range(0, len(Dependencies) ):
        x = set (Dependencies[i][0])
        y = set (Dependencies[i][1])
        
        for j in range (0, len(Dependencies) ):
            xb = set (Dependencies[j][0])
            yb = set (Dependencies[j][1])
            
            if x == xb and y != yb:
                y = y.union(yb)
            else:
                continue
        # Mend Sets into original format
        x = "".join(x)
        y = "".join(y)
        if (x,y) not in Output: # Duplicate Checker
            Output.append( (x,y) )
    return Output

# Assumes that each the functional dependencies completely covers all 
# attributes in the relation.
# 
# Finds the superkey for that set of relations. Presumably used once the 
# 3NF Form is found.
# 
# Input Format:
# T = [("ABH","CK"),("A","D"),("C","E"),("BGH","F"),("F","AD"),("E","F"),("BH","E")]
#
# Output Format:
# A the string representation of the X in X->Y, it is drawing from the input
# functional dependencies.
#
# Note: If no superkey is found then nothing is returned, check for this condition.


def Get_SuperKey(FDependencies):
    Attributes = ""
    for FD in FDependencies:
        Attributes += FD[0]
        Attributes += FD[1]
        
    Attributes = set( list(Attributes) )
    
    for FD in FDependencies:
        FD_Closure = closure(FD[0],FDependencies)
        if FD_Closure == Attributes:
            return FD[0]


T = [('AB', 'CDE'),('C', 'AD'),('D', 'AE'),('B', 'F')]

print ( NF3decomp(T) )


print ( Get_SuperKey(T) )